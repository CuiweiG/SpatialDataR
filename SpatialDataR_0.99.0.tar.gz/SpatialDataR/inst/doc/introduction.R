## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----read-store---------------------------------------------------------------
library(SpatialDataR)
library(S4Vectors)

store_path <- system.file("extdata", "xenium_mini.zarr",
    package = "SpatialDataR")
sd <- readSpatialData(store_path)
sd

## ----element-summary----------------------------------------------------------
elementSummary(sd)

## ----accessors----------------------------------------------------------------
# Points (loaded as DataFrame)
pts <- spatialPoints(sd)[["transcripts"]]
head(pts)

# Shapes
shp <- shapes(sd)[["cell_boundaries"]]
head(shp)

# Tables (obs/var metadata)
tbl <- tables(sd)[["table"]]
head(tbl$obs)

# Image reference
images(sd)[["morphology"]][c("name", "type")]

## ----selective----------------------------------------------------------------
sd_pts <- readSpatialData(store_path,
    elements = c("points", "shapes"))
elementSummary(sd_pts)

## ----subset-------------------------------------------------------------------
sub <- sd["transcripts"]
sub

## ----transforms-basic---------------------------------------------------------
# Pixel-to-micron scaling (Xenium: 0.2125 um/pixel)
ct <- CoordinateTransform("affine",
    affine = diag(c(0.2125, 0.2125, 1)),
    input_cs = "pixels", output_cs = "microns")
ct

## ----element-transform--------------------------------------------------------
# Get the transform from image metadata
ct_img <- elementTransform(images(sd)[["morphology"]])
ct_img

## ----apply-transform----------------------------------------------------------
# DataFrame
pts_sample <- DataFrame(x = c(100, 200, 300),
    y = c(50, 150, 250))
pts_um <- transformCoords(pts_sample, ct)
pts_um

# Matrix (also supports 3D: Nx3)
coords <- matrix(c(100, 200, 50, 150), ncol = 2)
colnames(coords) <- c("x", "y")
transformCoords(coords, ct)

## ----compose------------------------------------------------------------------
scale_ct <- CoordinateTransform("affine",
    affine = diag(c(0.5, 0.5, 1)),
    input_cs = "raw", output_cs = "scaled")

translate_ct <- CoordinateTransform("affine",
    affine = matrix(c(1,0,100, 0,1,200, 0,0,1),
        nrow = 3, byrow = TRUE),
    input_cs = "scaled", output_cs = "global")

combined <- composeTransforms(scale_ct, translate_ct)
combined

# Equivalent to: first scale by 0.5, then shift by (100, 200)
pts_test <- DataFrame(x = c(10), y = c(20))
transformCoords(pts_test, combined)

## ----invert-------------------------------------------------------------------
inv <- invertTransform(ct)
inv

# Roundtrip: pixels -> microns -> pixels
pts_orig <- DataFrame(x = c(100), y = c(200))
pts_fwd <- transformCoords(pts_orig, ct)
pts_back <- transformCoords(pts_fwd, inv)
pts_back  # Should match pts_orig

## ----bbox-query---------------------------------------------------------------
# Full dataset
nrow(spatialPoints(sd)[["transcripts"]])

# Subset to [0, 2] x [0, 2] microns
sub_sd <- bboxQuery(sd, xmin = 0, xmax = 2,
    ymin = 0, ymax = 2)
nrow(spatialPoints(sub_sd)[["transcripts"]])

## ----bbox-dataframe-----------------------------------------------------------
# Also works directly on DataFrames
sub_pts <- bboxQuery(pts, xmin = 0, xmax = 1,
    ymin = 0, ymax = 1)
nrow(sub_pts)

## ----coord-systems------------------------------------------------------------
cs <- coordinateSystems(sd)
str(cs)

## ----session------------------------------------------------------------------
sessionInfo()

